version = 3
ScenarioInfo = {
  Configurations={
    standard={
      customprops={ ExtraArmies="ARMY_9 NEUTRAL_CIVILIAN" },
      teams={
        {
          armies={
            "ARMY_1",
            "ARMY_2",
            "ARMY_3",
            "ARMY_4",
            "ARMY_5",
            "ARMY_6",
            "ARMY_7",
            "ARMY_8"
          },
          name="FFA"
        }
      }
    }
  },
  description="<LOC SCMP_haz09_Description>Fight for world domination! Let the world be yours!",
  map="/maps/SCMP_haz09.v0002/SCMP_haz09.scmap",
  map_version=2,
  name="World Domination",
  norushoffsetX_ARMY_1=0,
  norushoffsetX_ARMY_2=64,
  norushoffsetX_ARMY_3=64,
  norushoffsetX_ARMY_4=0,
  norushoffsetX_ARMY_5=-64,
  norushoffsetX_ARMY_6=32,
  norushoffsetX_ARMY_7=-32,
  norushoffsetX_ARMY_8=90,
  norushoffsetY_ARMY_1=32,
  norushoffsetY_ARMY_2=32,
  norushoffsetY_ARMY_3=-128,
  norushoffsetY_ARMY_4=0,
  norushoffsetY_ARMY_5=-128,
  norushoffsetY_ARMY_6=-96,
  norushoffsetY_ARMY_7=-64,
  norushoffsetY_ARMY_8=-32,
  norushradius=256,
  preview="",
  save="/maps/SCMP_haz09.v0002/SCMP_haz09_save.lua",
  script="/maps/SCMP_haz09.v0002/SCMP_haz09_script.lua",
  size={ 4096, 4096 },
  starts=true,
  type="skirmish"
}

